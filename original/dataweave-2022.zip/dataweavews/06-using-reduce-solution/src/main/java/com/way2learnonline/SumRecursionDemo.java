package com.way2learnonline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SumRecursionDemo {

	public static void main(String[] args) {
			List<Integer> numbers=new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9,10));
		
		int sum=sum(numbers);
		System.out.println("Sum="+sum);

	}
	
	public static int sum(List<Integer> numbers) {
		
		if(numbers.isEmpty()) {
			return 0;
		}else {
			int firstNumber=numbers.remove(0);
			return firstNumber+sum(numbers);
		}
	}
	

}
